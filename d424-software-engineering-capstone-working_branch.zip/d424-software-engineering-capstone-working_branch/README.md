<strong>Delivery Route Planner Version 1.0</strong>

# WESTERN GOVERNORS UNIVERSITY 
## D424 – SOFTWARE ENGINEERING CAPSTONE
This is a delivery route planner mobile application. This app allows users to save and delete information related to delivery routes such as:
Route details, stop details, and report generation for routes. 